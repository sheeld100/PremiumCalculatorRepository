using Microsoft.AspNetCore.Mvc;
using PremiumCalculatorApp.Models;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Diagnostics;


namespace PremiumCalculatorApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PremiumController : ControllerBase
    {
        private readonly ILogger<PremiumController> _logger;

        public PremiumController(ILogger<PremiumController> logger)
        {
            _logger = logger;
        }

        private readonly Dictionary<string, double> _occupationFactors = new()
        {
            { "Cleaner", 11.50 },
            { "Doctor", 1.5 },
            { "Author", 2.25 },
            { "Farmer", 31.75 },
            { "Mechanic", 31.75 },
            { "Florist", 11.50 },
            { "Other", 31.75 }
        };

        // POST: api/Premium
        [HttpPost]
        public IActionResult CalculatePremium([FromBody] PremiumRequest model)
        {
            try
            {
                if (ModelState.IsValid && _occupationFactors.ContainsKey(model.Occupation))
                {
                    var factor = _occupationFactors[model.Occupation];
                    model.MonthlyPremium = (model.DeathSumInsured * factor * model.Age) / 1000 * 12;
                    return Ok(model);
                }
                else
                {
                    return BadRequest("Invalid input data.");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error calculating premium for user: {Name}", model.Name);
                return StatusCode(500, "An unexpected error occurred. Please try again later.");
            }
        }
    }
}
