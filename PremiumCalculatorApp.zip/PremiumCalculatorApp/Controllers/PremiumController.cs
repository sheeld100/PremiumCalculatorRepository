using Microsoft.AspNetCore.Mvc;
using PremiumCalculatorApp.Models;

namespace PremiumCalculatorApp.Controllers
{

    [Route("[controller]")]
    public class PremiumController : Controller
    {
        private readonly Dictionary<string, double> _occupationFactors = new()
        {
            { "Cleaner", 11.50 },
            { "Doctor", 1.5 },
            { "Author", 2.25 },
            { "Farmer", 31.75 },
            { "Mechanic", 31.75 },
            { "Florist", 11.50 },
            { "Other", 31.75 }
        };

       
        public IActionResult Index()
        {
            PremiumRequest request = new PremiumRequest
            {
                Name = "Sheela Dash",
                DateOfBirth = new DateTime(1990, 5, 15),
                Occupation= "Cleaner"
            };
            return View(request);
        }

        [HttpPost("")]
        public IActionResult Index(PremiumRequest model)
        {
            if (ModelState.IsValid && _occupationFactors.ContainsKey(model.Occupation))
            {
                var factor = _occupationFactors[model.Occupation];
                model.MonthlyPremium = (model.DeathSumInsured * factor * model.Age) / 1000 * 12;
            }

            return View(model);
        }
    }
}
