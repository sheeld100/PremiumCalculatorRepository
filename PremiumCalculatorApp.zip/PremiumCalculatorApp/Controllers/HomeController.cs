using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using PremiumCalculatorApp.Models;
using Microsoft.AspNetCore.Diagnostics;

namespace PremiumCalculatorApp.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
        return View();
    }

    public IActionResult Privacy()
    {
        return View();
    }

    
public IActionResult Error(int? statusCode = null)
{
    if (statusCode.HasValue)
    {
        ViewBag.StatusCode = statusCode;
    }

    var exceptionFeature = HttpContext.Features.Get<IExceptionHandlerFeature>();
    if (exceptionFeature != null)
    {
        ViewBag.ExceptionMessage = exceptionFeature.Error.Message;
    }

    return View("Error"); // Located in Views/Shared/Error.cshtml
}

    
}
