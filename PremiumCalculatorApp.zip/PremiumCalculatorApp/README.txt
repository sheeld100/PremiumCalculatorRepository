Open the application using Visual Studio or VS Code.

In VS Code Go to Terminal--> New Terminal 

command : PS C:\.NetApp\PremiumCalculatorApp> dotnet run

After running successfully access below URL
http://localhost:5252/Premium

clarification: Only Name, DOB, Occupation are required fields.
I have used VS Code as I don't have Visual Studio I=installed
I am not able to access GIT, so I couldn't upload in GIT Repository