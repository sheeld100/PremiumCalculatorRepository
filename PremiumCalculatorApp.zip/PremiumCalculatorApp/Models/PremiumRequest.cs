
namespace PremiumCalculatorApp.Models
{
    public class PremiumRequest
    {
        public required string Name { get; set; }
        public required DateTime DateOfBirth { get; set; }
        public int Age => DateTime.Now.Year - DateOfBirth.Year;
        public required string Occupation { get; set; }
        public double DeathSumInsured { get; set; }
        public double? MonthlyPremium { get; set; }
    }
}
