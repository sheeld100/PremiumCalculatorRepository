using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace PremiumCalculatorApp.Models
{
    public class PremiumRequest
    {
        [Required(ErrorMessage = "Name is required.")]
        public required string Name { get; set; }

        [Required(ErrorMessage = "Date of birth is required.")]
        public required DateTime DateOfBirth { get; set; }

        [Required(ErrorMessage = "Occupation is required.")]
        [ValidOccupation]
        public required string Occupation { get; set; }

        [Range(1, double.MaxValue, ErrorMessage = "Death sum insured must be greater than 0.")]
        public double DeathSumInsured { get; set; }
        public int Age => DateTime.Now.Year - DateOfBirth.Year;
        public double? MonthlyPremium { get; }
    }
    
    
    
public class ValidOccupationAttribute : ValidationAttribute
{
    private static readonly HashSet<string> _validOccupations = new()
    {
        "Cleaner", "Doctor", "Author", "Farmer", "Mechanic", "Florist", "Other"
    };

    protected override ValidationResult? IsValid(object? value, ValidationContext? validationContext)
    {
        if (value is string occupation && _validOccupations.Contains(occupation))
        {
            return ValidationResult.Success;
        }

        return new ValidationResult($"Occupation '{value}' is not valid. Choose from: {string.Join(", ", _validOccupations)}.");
    }
}

}
